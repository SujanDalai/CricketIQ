# LLM module init
